export enum QUERY_KEYS {
    GET_CURRENT_ACCOUNT="getCurrentAccount",
    GET_MUSICS="getMusics",
    GET_ADVERTISING_MUSICS="getAdvertisingMusics",
    GET_FILTER_MUSICS="getFilterMusics",
}