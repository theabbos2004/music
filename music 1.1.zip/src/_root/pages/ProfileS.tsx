import { ProfileSComp } from "../../components";

export default function ProfileS() {
  return (
    <section className="min-h-[100vh] w-full">
      <ProfileSComp/>
    </section>
  )
}
