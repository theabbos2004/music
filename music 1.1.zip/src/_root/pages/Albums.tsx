
export default function Albums() {
  return (
    <div>Albums</div>
  )
}
