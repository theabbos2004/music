import { PriviteSComp } from '../../components';

export default function PriviteS() {
 
  return (
    <section className='min-h-[100vh]'>
        <PriviteSComp/>
    </section>
  )
}
